public class Comp {
    String brand;
    String model;
    int pric;
    int memori;

    @Override
    public String toString() {
        return "Comp{" +
                "brand='" + brand + '\'' +
                ", model='" + model + '\'' +
                ", pric=" + pric +
                ", memori=" + memori +
                '}';
    }
}