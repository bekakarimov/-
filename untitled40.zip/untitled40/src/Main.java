import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;



// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
      Comp comp = new Comp();
        comp.model = "hp";
        comp.pric = 300;
        comp.memori = 24;

        Comp comp2 = new Comp();
        comp2.model = "lenove";
        comp2.pric = 20;
        comp2.memori = 687;



        Comp comp3 = new Comp();
        comp3.model = "asus";
        comp3.pric = 100;
        comp3.memori =400;

        System.out.println(comp);
        System.out.println(comp2);
        System.out.println(comp3);





    }




            }






