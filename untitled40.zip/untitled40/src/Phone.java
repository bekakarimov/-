public class Phone {
    String brand;
    String model;
    int pric;
    int  memori;
    public void call(){
        System.out.println(brand+""+model+""+"phone is calling");

    }
     public String listen(){
        return "listening"+
                brand+""+model;
     }
    @Override
    public String toString() {
        return "Phone{" +
                "brand='" + brand + '\'' +
                ", model='" + model + '\'' +
                ", pric=" + pric +
                ", memori=" + memori +
                '}';
    }
}
